const urlInput = document.getElementById('api-url');
const saveBtn  = document.getElementById('save-btn');
const savedMsg = document.getElementById('saved-msg');

function normalizeUrl(raw) {
  try {
    const u = new URL(raw.trim().replace(/\/$/, ''));
    return u.origin;
  } catch {
    return null;
  }
}

// Load existing value
chrome.storage.sync.get(['apiUrl'], ({ apiUrl }) => {
  if (apiUrl) urlInput.value = apiUrl;
});

saveBtn.addEventListener('click', () => {
  const url = normalizeUrl(urlInput.value);
  if (!url) {
    urlInput.style.borderColor = '#e50914';
    return;
  }
  urlInput.style.borderColor = '#333';
  chrome.storage.sync.set({ apiUrl: url }, () => {
    savedMsg.style.display = 'block';
    setTimeout(() => { savedMsg.style.display = 'none'; }, 2000);
  });
});
