const $ = (id) => document.getElementById(id);

const setupEl    = $('setup');
const mainEl     = $('main');
const urlInput   = $('api-url-input');
const saveBtn    = $('save-url-btn');
const accessBtn  = $('access-btn');
const statusDot  = $('status-dot');
const statusTxt  = $('status-text');
const statusLbl  = $('status-label');
const toastEl    = $('toast');
const settingsBtn = $('settings-btn');

let activeCookieValue = null;

// ── Helpers ────────────────────────────────────────────────────────────────

function showToast(msg, type = 'error') {
  toastEl.textContent = msg;
  toastEl.className = `toast ${type}`;
  toastEl.style.display = 'block';
  clearTimeout(toastEl._t);
  toastEl._t = setTimeout(() => { toastEl.style.display = 'none'; }, 8000);
}

function setStatus(dot, text, label = '') {
  statusDot.className = `dot ${dot}`;
  statusTxt.textContent = text;
  statusLbl.textContent = label;
}

function normalizeUrl(raw) {
  try {
    const u = new URL(raw.trim().replace(/\/$/, ''));
    return u.origin;
  } catch {
    return null;
  }
}

// ── Netscape cookie file parser ────────────────────────────────────────────
// Format per line: domain \t subdomain_flag \t path \t secure \t expiry \t name \t value

function parseNetscapeCookies(raw) {
  const cookies = [];
  const lines = raw.split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;

    const parts = trimmed.split('\t');
    if (parts.length < 7) continue;

    const [domain, , path, secureStr, expiryStr, name, ...valueParts] = parts;
    const value = valueParts.join('\t'); // re-join in case value had tabs
    const secure = secureStr === 'TRUE';
    const expiry = parseInt(expiryStr, 10);

    cookies.push({ domain, path, secure, expiry, name, value });
  }
  return cookies;
}

// ── Setup screen ────────────────────────────────────────────────────────────

function showSetup() {
  setupEl.style.display = 'block';
  mainEl.style.display  = 'none';
}

function showMain() {
  setupEl.style.display = 'none';
  mainEl.style.display  = 'block';
}

saveBtn.addEventListener('click', () => {
  const url = normalizeUrl(urlInput.value);
  if (!url) { urlInput.style.borderColor = '#e50914'; return; }
  chrome.storage.sync.set({ apiUrl: url }, () => {
    showMain();
    fetchCookieStatus(url);
  });
});

settingsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());

// ── Cookie status ────────────────────────────────────────────────────────────

async function fetchCookieStatus(apiUrl) {
  setStatus('pulse', 'Checking...');
  accessBtn.disabled = true;
  activeCookieValue = null;

  try {
    const res = await fetch(`${apiUrl}/api/access`, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    if (data.found && data.cookieValue) {
      activeCookieValue = data.cookieValue;
      // Detect format: Netscape file has tabs
      const parsed = parseNetscapeCookies(data.cookieValue);
      const count = parsed.length;
      if (count > 0) {
        setStatus('green', 'Cookies ready', `${count} cookies · ${data.label || ''}`);
      } else {
        setStatus('green', 'Cookie available', data.label || '');
      }
      accessBtn.disabled = false;
    } else {
      setStatus('grey', 'No active cookie', 'Ask admin to activate one');
    }
  } catch (err) {
    setStatus('grey', 'Cannot reach API', 'Check settings');
  }
}

// ── Cookie injection helpers ──────────────────────────────────────────────────

function setCookie(details) {
  return new Promise((resolve, reject) => {
    chrome.cookies.set(details, (cookie) => {
      if (chrome.runtime.lastError) {
        reject(new Error(`${details.name}: ${chrome.runtime.lastError.message}`));
      } else {
        resolve(cookie);
      }
    });
  });
}

function removeCookie(details) {
  return new Promise((resolve) => {
    chrome.cookies.remove(details, () => resolve());
  });
}

async function clearNetflixCookies() {
  const [a, b] = await Promise.all([
    new Promise(r => chrome.cookies.getAll({ domain: 'netflix.com' }, r)),
    new Promise(r => chrome.cookies.getAll({ domain: '.netflix.com' }, r)),
  ]);
  const all = [...(a || []), ...(b || [])];
  const seen = new Set();
  const unique = all.filter(c => {
    const k = c.name + c.domain;
    return seen.has(k) ? false : seen.add(k);
  });
  await Promise.all(unique.map((c) => {
    const host = c.domain.replace(/^\./, '');
    return removeCookie({ url: `https://${host}${c.path || '/'}`, name: c.name });
  }));
}

// ── Inject & open Netflix ────────────────────────────────────────────────────

async function injectAndOpen() {
  if (!activeCookieValue) return;

  accessBtn.disabled = true;
  accessBtn.textContent = 'Injecting...';

  try {
    await clearNetflixCookies();

    const parsed = parseNetscapeCookies(activeCookieValue);
    const now = Math.floor(Date.now() / 1000);
    const defaultExpiry = now + 60 * 60 * 24 * 30; // 30 days

    if (parsed.length === 0) {
      // Fallback: treat as a raw netflixId value (single cookie)
      await setCookie({
        url: 'https://www.netflix.com',
        name: 'netflixId',
        value: activeCookieValue.trim(),
        domain: '.netflix.com',
        path: '/',
        secure: true,
        httpOnly: true,
        expirationDate: defaultExpiry,
      });
    } else {
      // Inject all cookies from the Netscape file
      const errors = [];
      for (const c of parsed) {
        // Build the url from domain for chrome.cookies.set
        const host = c.domain.startsWith('.') ? 'www' + c.domain : c.domain;
        const url = `https://${host}${c.path || '/'}`;

        // Expiry: 0 means session cookie; set a real expiry so they persist
        const expirationDate = (!c.expiry || c.expiry === 0) ? defaultExpiry : c.expiry;

        try {
          await setCookie({
            url,
            name: c.name,
            value: c.value,
            domain: c.domain,
            path: c.path || '/',
            secure: c.secure,
            expirationDate,
          });
        } catch (err) {
          errors.push(err.message);
        }
      }

      if (errors.length > 0 && errors.length === parsed.length) {
        throw new Error(`All ${parsed.length} cookies failed:\n${errors[0]}`);
      } else if (errors.length > 0) {
        console.warn('Some cookies failed to set:', errors);
      }
    }

    // Open Netflix
    const [existing] = await new Promise(r =>
      chrome.tabs.query({ url: '*://*.netflix.com/*' }, r)
    );
    if (existing) {
      chrome.tabs.update(existing.id, { url: 'https://www.netflix.com', active: true });
      chrome.windows.update(existing.windowId, { focused: true });
    } else {
      chrome.tabs.create({ url: 'https://www.netflix.com' });
    }

    window.close();
  } catch (err) {
    showToast(err.message);
    accessBtn.disabled = false;
    accessBtn.textContent = 'Access Netflix';
  }
}

accessBtn.addEventListener('click', injectAndOpen);

// ── Init ────────────────────────────────────────────────────────────────────

chrome.storage.sync.get(['apiUrl'], ({ apiUrl }) => {
  if (!apiUrl) { showSetup(); } else { showMain(); fetchCookieStatus(apiUrl); }
});
